export { default as Labyrinth } from './Labyrinth';
