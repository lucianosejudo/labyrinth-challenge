export { Labyrinth as Solution } from './Labyrinth';
